import { HKCharacterData } from "./data/character-data.js";
import { buildBugActorDefaults } from "./data/bug-templates.js";
import { flattenTraitLibrary } from "./data/trait-library.js";
import { HKCharacterSheet } from "./sheets/character-sheet.js";
import { HKCharmData } from "./data/charm-data.js";
import { HKCharmSheet } from "./sheets/charm-sheet.js";
import { HKTraitData, HKPathData } from "./data/feature-item-data.js";
import { HKTechniqueData } from "./data/technique-data.js";
import { HKInventoryItemData } from "./data/inventory-item-data.js";
import { HKFeatureItemSheet } from "./sheets/feature-item-sheet.js";
import { HK_EFFECT_CATALOG, getOrderedEffectStatuses } from "./data/effects-catalog.js";
import { HKStatusData } from "./data/status-data.js";
import { HKStatusSheet } from "./sheets/status-sheet.js";
import { buildStatusItemData } from "./rules/status-items.js";
import { planCatalogEffectDeduplication } from "./rules/effects-sheet.js";
import { activateAttributeRollControls } from "./rolls/chat-reroll.js";

Hooks.once("init", () => {
  console.log("Hollow Knight RPG | Initializing system");

  // Put the seven core HKRPG combat conditions at the top of the Token HUD.
  // Native Foundry entries are reused where they already represent the condition.
  CONFIG.statusEffects = getOrderedEffectStatuses(CONFIG.statusEffects ?? []);

  CONFIG.Actor.dataModels.character = HKCharacterData;
  CONFIG.Actor.dataModels.largeBug = HKCharacterData;
  CONFIG.Actor.dataModels.mediumBug = HKCharacterData;
  CONFIG.Actor.dataModels.smallBug = HKCharacterData;
  CONFIG.Item.dataModels.charm = HKCharmData;
  CONFIG.Item.dataModels.trait = HKTraitData;
  CONFIG.Item.dataModels.path = HKPathData;
  CONFIG.Item.dataModels.technique = HKTechniqueData;
  CONFIG.Item.dataModels.status = HKStatusData;
  for (const type of ["equipment", "weapon", "shield", "armor"]) {
    CONFIG.Item.dataModels[type] = HKInventoryItemData;
  }

  Actors.unregisterSheet("core", ActorSheet);
  Items.registerSheet("hollow-knight-rpg", HKFeatureItemSheet, {
    types: ["trait", "path", "technique"],
    makeDefault: true,
    label: "HKRPG.Sheets.FeatureItem"
  });

  Items.registerSheet("hollow-knight-rpg", HKCharmSheet, {
    types: ["charm"],
    makeDefault: true,
    label: "HKRPG.Sheets.Charm"
  });

  Items.registerSheet("hollow-knight-rpg", HKStatusSheet, {
    types: ["status"],
    makeDefault: true,
    label: "HKRPG.Sheets.Status"
  });

  Actors.registerSheet("hollow-knight-rpg", HKCharacterSheet, {
    types: ["character", "largeBug", "mediumBug", "smallBug"],
    makeDefault: true,
    label: "HKRPG.Sheets.Character"
  });

});


const BUG_ACTOR_TYPES = ["largeBug", "mediumBug", "smallBug"];
Hooks.on("preCreateActor", (actor) => {
  if (BUG_ACTOR_TYPES.includes(actor.type)) actor.updateSource(buildBugActorDefaults(actor.type));
});

async function ensureTraitLibrary() {
  if (!game.user?.isGM || !game.items) return;
  const folderCache = new Map();
  const getFolder = async (name, parent = null) => {
    const key = `${parent?.id ?? "root"}:${name}`;
    if (folderCache.has(key)) return folderCache.get(key);
    let folder = game.folders.find((entry) => entry.type === "Item" &&
      entry.name === name && (entry.folder?.id ?? null) === (parent?.id ?? null) &&
      entry.getFlag?.("hkrpg", "traitLibraryFolder"));
    if (!folder) folder = await Folder.implementation.create({
      name, type: "Item", folder: parent?.id ?? null,
      flags: { hkrpg: { traitLibraryFolder: true } }
    });
    folderCache.set(key, folder);
    return folder;
  };
  const categoryNames = {
    naturalWeapon:"01 · Природное оружие", characteristics:"02 · Черты характеристик",
    mind:"03 · Черты разума", physiological:"04 · Физиологические черты",
    senses:"05 · Черты чувств", mystical:"06 · Мистические черты",
    body:"07 · Черты тела", movement:"08 · Черты движения",
    naturalDefense:"09 · Черты природной защиты"
  };
  const existing = new Map(game.items.contents
    .filter((item) => item.type === "trait" && item.getFlag?.("hkrpg", "traitLibraryId"))
    .map((item) => [item.getFlag("hkrpg", "traitLibraryId"), item]));
  const itemMap = new Map(existing);
  const folders = new Map();
  for (const entry of flattenTraitLibrary()) {
    let categoryFolder = folders.get(entry.category);
    if (!categoryFolder) {
      categoryFolder = await getFolder(categoryNames[entry.category] ?? "Черты · Прочее");
      folders.set(entry.category, categoryFolder);
    }
    const parentFolder = entry.parentId ? folders.get(entry.parentId) : null;
    const folder = entry.kind === "main" ? categoryFolder :
      await getFolder(entry.name, parentFolder ?? categoryFolder);
    folders.set(entry.id, folder);
    const modifiers = {
      dazzling: { cute: 1 },
      dull: { insight: -1 },
      fragile: { shell: -1 },
      graceful: { grace: 0.5 },
      heartful: { heartMax: 1 },
      frail: { heartMax: -1 },
      insightful: { insight: 0.5 },
      mighty: { might: 0.5, spook: 0.5 },
      slow: { speed: -1 },
      weak: { might: -1, cute: 0.5 },
      clumsy: { grace: -1 },
      spooky: { spook: 1 },
      sturdy: { shell: 0.5 },
      fast: { speed: 1 }
    }[entry.id] ?? {};
    const system = {
      kind: entry.kind, parentId: "", parentLibraryId: entry.parentId ?? "",
      libraryId: entry.id, group: entry.category, slot: 0, category: entry.category,
      selected: entry.kind === "main", hunger: entry.hunger, cute: modifiers.cute ?? 0,
      spook: modifiers.spook ?? 0, might: modifiers.might ?? 0,
      insight: modifiers.insight ?? 0, shell: modifiers.shell ?? 0,
      grace: modifiers.grace ?? 0, heartMax: modifiers.heartMax ?? 0,
      staminaMax: modifiers.staminaMax ?? 0, soulMax: modifiers.soulMax ?? 0,
      satietyMax: modifiers.satietyMax ?? 0, speed: modifiers.speed ?? 0,
      description: entry.description, effects: entry.description
    };
    const prior = itemMap.get(entry.id);
    if (prior) {
      await prior.update({ name: entry.name, folder: folder.id, system,
        ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS?.OBSERVER ?? 2 },
        "flags.hkrpg.traitLibraryVersion": 1 });
      itemMap.set(entry.id, prior);
    } else {
      const [created] = await Item.implementation.createDocuments([{
        name: entry.name, type: "trait",
        img: "icons/commodities/biological/antenna-insect-green.webp",
        folder: folder.id, system,
        ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS?.OBSERVER ?? 2 },
        flags: { hkrpg: { traitLibraryId: entry.id, traitLibraryVersion: 1 } }
      }]);
      itemMap.set(entry.id, created);
    }
  }
}

async function ensureStatusReferenceItems() {
  if (!game.user?.isGM || !game.items) return;

  let folder = game.folders.find((entry) =>
    entry.type === "Item" && entry.getFlag?.("hkrpg", "statusReferenceFolder")
  );
  if (!folder) {
    folder = await Folder.implementation.create({
      name: "Hollow Knight RPG — Статусы",
      type: "Item",
      flags: { hkrpg: { statusReferenceFolder: true } }
    });
  }

  const byStatusId = new Map();
  const duplicates = [];
  for (const item of game.items.contents) {
    const statusId = item.getFlag?.("hkrpg", "statusReferenceId");
    if (item.type !== "status" || !statusId) continue;
    if (byStatusId.has(statusId)) duplicates.push(item.id);
    else byStatusId.set(statusId, item);
  }
  if (duplicates.length) await Item.implementation.deleteDocuments(duplicates);

  const missing = [];
  const observer = CONST.DOCUMENT_OWNERSHIP_LEVELS?.OBSERVER ?? 2;
  for (const definition of HK_EFFECT_CATALOG) {
    const data = buildStatusItemData(definition);
    const existing = byStatusId.get(definition.id);
    if (!existing) {
      missing.push({
        ...data,
        folder: folder.id,
        ownership: { default: observer }
      });
      continue;
    }

    await existing.update({
      name: data.name,
      img: data.img,
      folder: folder.id,
      ownership: { default: observer },
      "system.statusId": data.system.statusId,
      "system.summary": data.system.summary,
      "system.rules": data.system.rules,
      "system.duration": data.system.duration,
      "system.source": data.system.source,
      "system.page": data.system.page,
      "system.bookVersion": data.system.bookVersion,
      "flags.hkrpg.statusReferenceId": definition.id,
      "flags.hkrpg.statusReferenceVersion": 1
    });
  }

  if (missing.length) await Item.implementation.createDocuments(missing);
}

Hooks.once("ready", async () => {
  try {
    await ensureStatusReferenceItems();
    await ensureTraitLibrary();
  } catch (error) {
    console.error("Hollow Knight RPG | Could not prepare status reference Items", error);
  }

  // Remove only stale effects that were generated by the previous, over-broad catalogue.
  // User-created Active Effects are left untouched.
  const currentIds = new Set(HK_EFFECT_CATALOG.map((effect) => effect.id));
  const actors = new Set(game.actors.contents);
  // Unlinked scene tokens own synthetic actors which are not in game.actors.
  for (const scene of game.scenes.contents) {
    for (const token of scene.tokens) {
      if (token.actor) actors.add(token.actor);
    }
  }
  for (const actor of actors) {
    const stale = actor.effects.filter((effect) => {
      const catalogId = effect.getFlag?.("hkrpg", "catalogId");
      return typeof catalogId === "string" && catalogId.startsWith("hkrpg-") && !currentIds.has(catalogId);
    });
    if (stale.length) {
      await actor.deleteEmbeddedDocuments("ActiveEffect", stale.map((effect) => effect.id));
    }

    const duplicatePlan = planCatalogEffectDeduplication(actor.effects, HK_EFFECT_CATALOG);
    for (const effectId of duplicatePlan.enableIds) {
      const effect = actor.effects.get(effectId);
      if (effect?.disabled) await effect.update({ disabled: false });
    }
    if (duplicatePlan.removeIds.length) {
      await actor.deleteEmbeddedDocuments("ActiveEffect", duplicatePlan.removeIds);
    }
  }
  console.log(`Hollow Knight RPG | Ready (v${game.system.version})`);
});
// Add selective reroll controls to attribute-check chat cards.
Hooks.on("renderChatMessageHTML", (message, html) => {
  activateAttributeRollControls(message, html);
});

// Add full rules summaries to the native Token HUD status-icon tooltips.
Hooks.on("renderTokenHUD", (app, html) => {
  const root = html?.[0] ?? html;
  if (!root?.querySelectorAll) return;
  const definitions = new Map();
  for (const entry of HK_EFFECT_CATALOG) {
    definitions.set(entry.id, entry);
    if (entry.coreStatusId) definitions.set(entry.coreStatusId, entry);
  }
  for (const control of root.querySelectorAll("[data-status-id], .status-effects .effect-control")) {
    const statusId = control.dataset.statusId ?? control.dataset.status;
    const catalogEntry = definitions.get(statusId);
    if (!catalogEntry) continue;
    const tooltip = [catalogEntry.name, catalogEntry.summary, catalogEntry.rules, `Длительность: ${catalogEntry.duration}`, catalogEntry.source].join("\n\n");
    control.dataset.tooltip = tooltip;
    control.dataset.tooltipClass = "hkrpg-status-tooltip";
    control.setAttribute("title", tooltip);
    control.setAttribute("aria-label", catalogEntry.name);
  }
});
