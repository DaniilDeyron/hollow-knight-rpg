import { HKCharacterData, HKSmallBugData, HKMediumBugData, HKLargeBugData } from "./data/character-data.js";
import { buildBugActorDefaults } from "./data/bug-templates.js";
import { HKCharacterSheet } from "./sheets/character-sheet.js";
import { HKCharmData } from "./data/charm-data.js";
import { HKCharmSheet } from "./sheets/charm-sheet.js";
import { HKTraitData, HKPathData } from "./data/feature-item-data.js";
import { HKTechniqueData } from "./data/technique-data.js";
import { HKInventoryItemData } from "./data/inventory-item-data.js";
import { HKFeatureItemSheet } from "./sheets/feature-item-sheet.js";
import { HK_EFFECT_CATALOG, getOrderedEffectStatuses } from "./data/effects-catalog.js";
import { HKStatusData } from "./data/status-data.js";
import { HKStatusSheet } from "./sheets/status-sheet.js";
import { buildStatusItemData } from "./rules/status-items.js";
import { planCatalogEffectDeduplication } from "./rules/effects-sheet.js";
import { activateAttributeRollControls } from "./rolls/chat-reroll.js";

Hooks.once("init", () => {
  console.log("Hollow Knight RPG | Initializing system");

  // Put the seven core HKRPG combat conditions at the top of the Token HUD.
  // Native Foundry entries are reused where they already represent the condition.
  CONFIG.statusEffects = getOrderedEffectStatuses(CONFIG.statusEffects ?? []);

  CONFIG.Actor.dataModels.character = HKCharacterData;
  CONFIG.Actor.dataModels.largeBug = HKLargeBugData;
  CONFIG.Actor.dataModels.mediumBug = HKMediumBugData;
  CONFIG.Actor.dataModels.smallBug = HKSmallBugData;
  CONFIG.Item.dataModels.charm = HKCharmData;
  CONFIG.Item.dataModels.trait = HKTraitData;
  CONFIG.Item.dataModels.path = HKPathData;
  CONFIG.Item.dataModels.technique = HKTechniqueData;
  CONFIG.Item.dataModels.status = HKStatusData;
  for (const type of ["equipment", "weapon", "shield", "armor"]) {
    CONFIG.Item.dataModels[type] = HKInventoryItemData;
  }

  Actors.unregisterSheet("core", ActorSheet);
  Items.registerSheet("hollow-knight-rpg", HKFeatureItemSheet, {
    types: ["trait", "path", "technique"],
    makeDefault: true,
    label: "HKRPG.Sheets.FeatureItem"
  });

  Items.registerSheet("hollow-knight-rpg", HKCharmSheet, {
    types: ["charm"],
    makeDefault: true,
    label: "HKRPG.Sheets.Charm"
  });

  Items.registerSheet("hollow-knight-rpg", HKStatusSheet, {
    types: ["status"],
    makeDefault: true,
    label: "HKRPG.Sheets.Status"
  });

  Actors.registerSheet("hollow-knight-rpg", HKCharacterSheet, {
    types: ["character", "largeBug", "mediumBug", "smallBug"],
    makeDefault: true,
    label: "HKRPG.Sheets.Character"
  });

});


const BUG_ACTOR_TYPES = ["largeBug", "mediumBug", "smallBug"];
Hooks.on("preCreateActor", (actor) => {
  if (!BUG_ACTOR_TYPES.includes(actor.type)) return;
  const defaults = buildBugActorDefaults(actor.type);
  // The type-specific DataModel owns system defaults; this hook only sets token footprint.
  actor.updateSource({ prototypeToken: defaults.prototypeToken });
});

async function ensureStatusReferenceItems() {
  if (!game.user?.isGM || !game.items) return;

  let folder = game.folders.find((entry) =>
    entry.type === "Item" && entry.getFlag?.("hkrpg", "statusReferenceFolder")
  );
  if (!folder) {
    folder = await Folder.implementation.create({
      name: "Hollow Knight RPG — Статусы",
      type: "Item",
      flags: { hkrpg: { statusReferenceFolder: true } }
    });
  }

  const byStatusId = new Map();
  const duplicates = [];
  for (const item of game.items.contents) {
    const statusId = item.getFlag?.("hkrpg", "statusReferenceId");
    if (item.type !== "status" || !statusId) continue;
    if (byStatusId.has(statusId)) duplicates.push(item.id);
    else byStatusId.set(statusId, item);
  }
  if (duplicates.length) await Item.implementation.deleteDocuments(duplicates);

  const missing = [];
  const observer = CONST.DOCUMENT_OWNERSHIP_LEVELS?.OBSERVER ?? 2;
  for (const definition of HK_EFFECT_CATALOG) {
    const data = buildStatusItemData(definition);
    const existing = byStatusId.get(definition.id);
    if (!existing) {
      missing.push({
        ...data,
        folder: folder.id,
        ownership: { default: observer }
      });
      continue;
    }

    await existing.update({
      name: data.name,
      img: data.img,
      folder: folder.id,
      ownership: { default: observer },
      "system.statusId": data.system.statusId,
      "system.summary": data.system.summary,
      "system.rules": data.system.rules,
      "system.duration": data.system.duration,
      "system.source": data.system.source,
      "system.page": data.system.page,
      "system.bookVersion": data.system.bookVersion,
      "flags.hkrpg.statusReferenceId": definition.id,
      "flags.hkrpg.statusReferenceVersion": 1
    });
  }

  if (missing.length) await Item.implementation.createDocuments(missing);
}

Hooks.once("ready", async () => {
  try {
    await ensureStatusReferenceItems();
  } catch (error) {
    console.error("Hollow Knight RPG | Could not prepare status reference Items", error);
  }

  // Remove only stale effects that were generated by the previous, over-broad catalogue.
  // User-created Active Effects are left untouched.
  const currentIds = new Set(HK_EFFECT_CATALOG.map((effect) => effect.id));
  const actors = new Set(game.actors.contents);
  // Unlinked scene tokens own synthetic actors which are not in game.actors.
  for (const scene of game.scenes.contents) {
    for (const token of scene.tokens) {
      if (token.actor) actors.add(token.actor);
    }
  }
  for (const actor of actors) {
    const stale = actor.effects.filter((effect) => {
      const catalogId = effect.getFlag?.("hkrpg", "catalogId");
      return typeof catalogId === "string" && catalogId.startsWith("hkrpg-") && !currentIds.has(catalogId);
    });
    if (stale.length) {
      await actor.deleteEmbeddedDocuments("ActiveEffect", stale.map((effect) => effect.id));
    }

    const duplicatePlan = planCatalogEffectDeduplication(actor.effects, HK_EFFECT_CATALOG);
    for (const effectId of duplicatePlan.enableIds) {
      const effect = actor.effects.get(effectId);
      if (effect?.disabled) await effect.update({ disabled: false });
    }
    if (duplicatePlan.removeIds.length) {
      await actor.deleteEmbeddedDocuments("ActiveEffect", duplicatePlan.removeIds);
    }
  }
  console.log(`Hollow Knight RPG | Ready (v${game.system.version})`);
});
// Add selective reroll controls to attribute-check chat cards.
Hooks.on("renderChatMessageHTML", (message, html) => {
  activateAttributeRollControls(message, html);
});

// Add full rules summaries to the native Token HUD status-icon tooltips.
Hooks.on("renderTokenHUD", (app, html) => {
  const root = html?.[0] ?? html;
  if (!root?.querySelectorAll) return;
  const definitions = new Map();
  for (const entry of HK_EFFECT_CATALOG) {
    definitions.set(entry.id, entry);
    if (entry.coreStatusId) definitions.set(entry.coreStatusId, entry);
  }
  for (const control of root.querySelectorAll("[data-status-id], .status-effects .effect-control")) {
    const statusId = control.dataset.statusId ?? control.dataset.status;
    const catalogEntry = definitions.get(statusId);
    if (!catalogEntry) continue;
    const tooltip = [catalogEntry.name, catalogEntry.summary, catalogEntry.rules, `Длительность: ${catalogEntry.duration}`, catalogEntry.source].join("\n\n");
    control.dataset.tooltip = tooltip;
    control.dataset.tooltipClass = "hkrpg-status-tooltip";
    control.setAttribute("title", tooltip);
    control.setAttribute("aria-label", catalogEntry.name);
  }
});
