/**
 * Только состояния и боевые эффекты из основных боевых правил
 * The Unofficial Hollow Knight RPG.
 * Не добавлять сюда заклинания, предметы, зелья, склянки, яды,
 * ловушки, черты персонажей или существ.
 */
export const HK_EFFECT_CATEGORIES = [
  { id: "combat", label: "Боевые эффекты и состояния" }
];

export const HK_EFFECT_CATALOG = [
  {
    id: "hkrpg-grappled", category: "combat", name: "Схвачен", coreStatusId: "grappled",
    icon: "icons/svg/net.svg",
    summary: "Существо удерживается противником и не может свободно перемещаться.",
    rules: "Схваченный жук получает −1 к броскам атаки и защиты и не может перемещаться по своей воле. В свой ход он может потратить 1 Выносливость и попытаться вырваться проверкой Мощи или Грации. Схвативший сопротивляется проверкой Мощи с бонусами захвата от природного оружия и придатков; обе стороны могут вкладывать Выносливость.",
    duration: "Пока цель не вырвется или захват не будет прекращён.",
    source: "Книга, с. 117"
  },
  {
    id: "hkrpg-off-balance", category: "combat", name: "Дисбаланс",
    icon: "icons/svg/daze.svg",
    summary: "Нарушает равновесие и уменьшает восстановление Выносливости.",
    rules: "За каждую единицу Дисбаланса жук получает на 1 Выносливость меньше при восстановлении в начале хода. Максимум — 3. После восстановления Выносливости в начале хода жук теряет 1 Дисбаланс. В свой ход он также может потратить Выносливость, чтобы убрать соответствующее количество Дисбаланса.",
    duration: "Снижается на 1 после восстановления Выносливости в начале хода; можно снять тратой Выносливости.",
    source: "Книга, с. 119–120"
  },
  {
    id: "hkrpg-deaths-door", category: "combat", name: "Врата Смерти",
    icon: "icons/svg/skull.svg",
    summary: "Сердце существа опустилось до 0, но оно ещё не погибло.",
    rules: "Когда Сердце падает до 0, жук оказывается у Врат Смерти. При первом таком случае после Отдыха он восстанавливает всю Выносливость. Весь последующий урон наносится Выносливости вместо Сердца, а Выносливость перестаёт восстанавливаться естественным образом. Если Выносливость падает до 0, жук умирает. После окончания сражения жук у Врат Смерти теряет сознание.",
    duration: "Пока жук не погибнет; после сражения он теряет сознание.",
    source: "Книга, с. 120"
  },
  {
    id: "hkrpg-unconscious", category: "combat", name: "Потеря сознания", coreStatusId: "unconscious",
    icon: "icons/svg/unconscious.svg",
    summary: "Существо не может самостоятельно двигаться или предпринимать действия.",
    rules: "Когда Сердце падает до 0, жук может добровольно потерять сознание. Это делает его менее приоритетной целью и полностью восстанавливает Выносливость, даже если он уже был у Врат Смерти после последнего Отдыха. Бессознательный жук не может двигаться или предпринимать действия своими силами. Получаемый урон наносится Выносливости, которая не восстанавливается естественным образом. При падении Выносливости до 0 жук умирает.",
    duration: "Пока жук не придёт в сознание; универсальная длительность не указана.",
    source: "Книга, с. 120"
  },
  {
    id: "hkrpg-suffocation", category: "combat", name: "Удушение",
    icon: "systems/hollow-knight-rpg/assets/icons/status/suffocation.svg",
    summary: "Существо находится в среде, где не может дышать.",
    rules: "Каждый ход удушения уменьшает максимум Выносливости жука на 1. Когда максимум Выносливости падает до 0, удушение начинает наносить урон Сердцу.",
    duration: "Прекращается, когда жук проводит целый ход в пригодном для дыхания окружении.",
    source: "Книга, с. 120"
  },
  {
    id: "hkrpg-dot", category: "combat", name: "Отложенный урон (ОУ)",
    icon: "icons/svg/blood.svg",
    summary: "Накопленный урон срабатывает постепенно в начале хода.",
    rules: "В начале своего хода жук получает природный урон, равный текущему значению ОУ; после этого значение ОУ уменьшается на 1. Сам ОУ не считается нанесением урона, но его срабатывание — считается. В свой ход жук может потратить Выносливость, чтобы убрать равное количество ОУ. ОУ игнорирует Понижение Урона, если оно прямо не защищает от постепенного урона. ОУ одного типа не складывается: применяется большее значение. ОУ разных типов может действовать одновременно.",
    duration: "Значение уменьшается на 1 после каждого срабатывания; может быть снижено тратой Выносливости.",
    source: "Книга, с. 120"
  },
  {
    id: "hkrpg-invisible", category: "combat", name: "Невидимость", coreStatusId: "invisible",
    icon: "icons/svg/invisible.svg",
    summary: "Существо невидимо для тех, кто не способен его обнаружить.",
    rules: "Атаки и защита против невидимого жука получают штраф −2. Если противник не знает о невидимом жуке, он не может уклониться или парировать его первую атаку. Невидимые жуки не провоцируют атаки.",
    duration: "Пока источник эффекта поддерживает невидимость или пока она не будет раскрыта согласно его правилам.",
    source: "Книга, с. 121"
  }
];

function statusEntries(statusEffects = []) {
  if (Array.isArray(statusEffects)) return statusEffects;
  if (statusEffects && typeof statusEffects.values === "function") {
    return Array.from(statusEffects.values());
  }
  if (statusEffects && typeof statusEffects[Symbol.iterator] === "function") {
    return Array.from(statusEffects);
  }
  return Object.values(statusEffects ?? {});
}

function configuredStatusIds(statusEffects = []) {
  return new Set(statusEntries(statusEffects)
    .map((status) => typeof status === "string" ? status : status?.id)
    .filter(Boolean));
}

/**
 * Use Foundry's built-in status ID when it already represents this condition.
 * Otherwise retain the system-specific ID so the condition remains available.
 */
export function getEffectStatusId(effect, configuredStatuses = []) {
  const existingIds = configuredStatusIds(configuredStatuses);
  return effect?.coreStatusId && existingIds.has(effect.coreStatusId)
    ? effect.coreStatusId
    : effect?.id;
}

/**
 * Register only statuses which are not already supplied by Foundry or another
 * active system/module. This keeps the Token HUD from showing duplicate icons.
 */
export function getEffectStatuses(existingStatuses = []) {
  const existingIds = configuredStatusIds(existingStatuses);
  return HK_EFFECT_CATALOG
    .filter((entry) => !existingIds.has(entry.id))
    .filter((entry) => !entry.coreStatusId || !existingIds.has(entry.coreStatusId))
    .map(({ id, name, icon, summary, rules, duration, source }) => ({
      id,
      name,
      img: icon,
      description: [summary, rules, `Длительность: ${duration}`, source].join("\n\n"),
      flags: { hkrpg: { catalogId: id } }
    }));
}
